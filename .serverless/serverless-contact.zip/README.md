# Seasonal Supper
---
React app that provides a list of produce that is in season according to state and month.
Each produce card will link to recipes containing that ingredient. 
