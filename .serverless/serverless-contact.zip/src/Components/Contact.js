import React, { Component } from 'react'
import axios from 'axios';

class Contact extends Component {
  state = {
    subject: "",
    message: "",
    email: ""
  }

  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  handleSubmit = (e) => {
    e.preventDefault()

    axios.post('https://tzynhs3pn6.execute-api.us-east-1.amazonaws.com/dev/contact', this.state)

      .then(res => {
        if (res.request.status === 201) {
          console.log('success!,', res)
        }
      })
      .catch(err => {
        console.log(err)
      });
  }

  render() {
    return (
      <div className="contact">
        <form >
          <h1>Contact Me</h1>
          <div className="contact__subject">
            <label>Subject</label>
            <input type="text" name="subject" value={this.state.subject} onChange={this.handleChange} />
          </div>
          <div className="contact__message">
            <label>Message</label>
            <textarea name="message" value={this.state.message} onChange={this.handleChange} />
          </div>
          <div className="contact__email">
            <label>Your Email Address</label>
            <input type="email" name="email" value={this.state.email} onChange={this.handleChange} />
          </div>
          <button className="btn" onClick={this.handleSubmit}>Submit</button>

        </form>

      </div>
    )
  }
}
export default Contact;